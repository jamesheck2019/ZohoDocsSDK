﻿Namespace JSON
    Public Class JSON_TagMetadata
        Public Property tagId As String
        Public Property tagName As String
    End Class
End Namespace
